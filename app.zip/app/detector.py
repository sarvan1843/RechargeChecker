from playwright.async_api import Page, TimeoutError


async def detect_topup(page: Page):
    """
    Detect Top-up Voucher using multiple fallback methods.
    """

    categories = []
    method = ""
    confidence = 0
    found = False

    print("\n========== TOP-UP DETECTOR ==========\n")

    # -----------------------------
    # LEVEL 1 : Desktop Categories
    # -----------------------------
    try:
        print("Trying Desktop Category Container...")

        buttons = page.locator(
            '[data-testid="desktopChangeCategory"] button'
        )

        count = await buttons.count()

        if count > 0:

            for i in range(count):
                label = await buttons.nth(i).get_attribute("aria-label")

                if label:
                    categories.append(label.strip())

            print(f"Desktop Categories Found : {len(categories)}")

            for c in categories:
                print(" -", c)

            if "Top-up Voucher" in categories:
                found = True
                method = "Desktop Button List"
                confidence = 100

    except Exception as e:
        print("Desktop Detection Error:", e)

    # -----------------------------
    # LEVEL 2 : Text Search
    # -----------------------------
    if not found:

        try:
            print("\nTrying Text Search...")

            locator = page.get_by_text("Top-up Voucher")

            if await locator.count() > 0:
                found = True
                method = "Visible Text"
                confidence = 70

        except Exception:
            pass

    # -----------------------------
    # LEVEL 3 : Body Text
    # -----------------------------
    if not found:

        try:
            print("\nTrying Body Text...")

            body = await page.locator("body").inner_text()

            if "Top-up Voucher" in body:
                found = True
                method = "Body Text"
                confidence = 60

        except Exception:
            pass

    # -----------------------------
    # LEVEL 4 : HTML Search
    # -----------------------------
    if not found:

        try:
            print("\nTrying HTML Search...")

            html = await page.content()

            if 'aria-label="Top-up Voucher"' in html:
                found = True
                method = "HTML Search"
                confidence = 40

        except Exception:
            pass

    print("\n========== RESULT ==========")
    print("Found      :", found)
    print("Method     :", method)
    print("Confidence :", confidence)
    print("============================\n")

    return {
        "found": found,
        "method": method,
        "confidence": confidence,
        "categories": categories
    }