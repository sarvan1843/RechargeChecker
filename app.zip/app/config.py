from pathlib import Path

# Project Root
BASE_DIR = Path(__file__).resolve().parent.parent

# Folders
LOGS_DIR = BASE_DIR / "logs"
SCREENSHOTS_DIR = BASE_DIR / "screenshots"

# Create folders automatically
LOGS_DIR.mkdir(exist_ok=True)
SCREENSHOTS_DIR.mkdir(exist_ok=True)

# Browser Settings
HEADLESS = False
SLOW_MO = 300

# Timeouts (milliseconds)
PAGE_TIMEOUT = 30000
ELEMENT_TIMEOUT = 15000