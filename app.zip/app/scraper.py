from playwright.async_api import async_playwright
import traceback

from app.logger import logger
from app.config import HEADLESS, SLOW_MO
from app.detector import detect_topup

print("########## NEW SCRAPER LOADED ##########")


async def open_jio_website(
    mobile=None,
    operator=None,
    circle=None,
):
    browser = None

    try:

        if mobile is None:
            mobile = "7869632727"

        print("=" * 60)
        print("STEP 1 : SCRAPER STARTED")
        print("=" * 60)
        print("Mobile   :", mobile)
        print("Operator :", operator)
        print("Circle   :", circle)

        logger.info("SCRAPER STARTED")

        async with async_playwright() as p:

            browser = await p.chromium.launch(
                headless=HEADLESS,
                slow_mo=SLOW_MO,
            )

            page = await browser.new_page(
                viewport={
                    "width": 1366,
                    "height": 768,
                }
            )

            print("Opening Jio Website...")

            await page.goto(
                "https://www.jio.com/selfcare/recharge/mobility/",
                wait_until="domcontentloaded",
                timeout=30000,
            )

            print("Jio Page Opened")

            input_box = page.locator("#submitNumber")

            await input_box.wait_for(timeout=15000)

            print("Input Found")

            await input_box.fill("")

            await input_box.type(
                mobile,
                delay=100,
            )

            print("Number Entered :", mobile)

            continue_btn = page.get_by_role(
                "button",
                name="Continue",
            )

            await continue_btn.wait_for(timeout=15000)

            print("Continue Button Found")

            await continue_btn.click()

            print("Continue Clicked")

            print("Waiting For Recharge Page...")

            print("Waiting For Recharge Page...")

try:
    await page.wait_for_selector(
        '[data-testid="desktopChangeCategory"]',
        timeout=15000,
    )
    print("Recharge page detected.")
except Exception:
    print("Desktop category not found, continuing anyway...")

            print("Current URL :", page.url)
            print("Page Title  :", await page.title())

            # -----------------------------
            # NEW DETECTOR
            # -----------------------------

            result = await detect_topup(page)

            topup_available = result["found"]

            detection_method = result["method"]

            confidence = result["confidence"]

            categories = result["categories"]

            print("\nDetector Result")
            print("----------------------")
            print("Topup       :", topup_available)
            print("Method      :", detection_method)
            print("Confidence  :", confidence)
            print("Categories  :", len(categories))

            await page.screenshot(
                path="screenshots/after_continue.png",
                full_page=True,
            )

            print("Screenshot Saved")

            print("Closing Browser...")

            await browser.close()

            return {                "success": True,
                "status": "Completed",
                "mobile": mobile,
                "operator": operator,
                "circle": circle,

                "topupAvailable": topup_available,
                "detectionMethod": detection_method,
                "confidence": confidence,
                "categories": categories,

                "plan": "",
                "validity": "",
                "expiryDate": "",
                "message": "Top-Up Check Completed",
                "error": None,
            }

    except Exception as e:

        print("\n" + "=" * 80)
        print("FULL TRACEBACK")
        print("=" * 80)

        traceback.print_exc()

        logger.exception("SCRAPER ERROR")

        if browser:
            try:
                await browser.close()
            except Exception:
                pass

        return {
            "success": False,
            "status": "Failed",
            "mobile": mobile,
            "operator": operator,
            "circle": circle,

            "topupAvailable": False,
            "detectionMethod": "",
            "confidence": 0,
            "categories": [],

            "plan": "",
            "validity": "",
            "expiryDate": "",
            "message": "Scraper Failed",
            "error": str(e),
        }